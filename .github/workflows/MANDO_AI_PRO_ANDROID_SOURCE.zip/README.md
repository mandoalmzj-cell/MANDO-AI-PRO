# MANDO AI PRO — Android project

A simple Android WebView shell for the MANDO AI PRO Arabic interface.

## Build

The repository workflow can build a debug APK with Java 17, Android SDK platform 35, and Gradle 8.7.

## AI connection

The app UI is not an embedded language model. To get model responses, configure an OpenAI-compatible API endpoint and model in settings. For a public release, use a secure backend proxy; do not ship a shared secret API key in the APK.

## Safety

The assistant system prompt is configured for lawful, defensive cybersecurity and programming education.
